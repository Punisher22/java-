//14_1 CLient side
import java.net.*;
import java.io.*;
class Client{       
    public static void main(String []args){
        try{
            Socket socket=new Socket("127.0.0.1",3000);
            DataOutputStream dou=new  DataOutputStream(socket.getOutputStream());
            String s="hello world";
            dou.writeUTF(s);
            System.out.println(s);
            socket.close();
        }catch(IOException e){
            System.out.println(e);
        }
    }
}

