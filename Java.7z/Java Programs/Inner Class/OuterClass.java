class OuterDemo {
    public OuterDemo() {
        System.out.println("Outer class created");
    }
    void display_Inner() {
        InnerDemo inner = new InnerDemo();
        inner.print();
     }
    class InnerDemo {
        public InnerDemo(){
            System.out.println("Inner class created");
        }
       public void print() {
          System.out.println("This is an inner class");
       }
    }
 }
class Main {
    public static void main(String args[]) {
       OuterDemo outer = new OuterDemo();
       outer.display_Inner();
    }
 }