// 14_2 client side
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.DatagramSocket;

class Client
{
    public static void main(final String[] array) throws IOException {
        final DatagramSocket datagramSocket = new DatagramSocket();
        final InetAddress localHost = InetAddress.getLocalHost();
        final byte[] bytes = "Hello World".getBytes();
        datagramSocket.send(new DatagramPacket(bytes, bytes.length, localHost, 1234));
    }
}