package package_one; 

public class ClassOne { 
	public void methodClassOne() { 
		System.out.println("Hello there its ClassOne"); 
	} 
} 
