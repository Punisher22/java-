abstract class Popcorn {
    abstract void flavor();
}
class CheesePopcorn extends Popcorn{
    public void flavor(){
        System.out.println("Cheese Popcorn");
    }
}
class MasalaPopcorn extends Popcorn{
    public void flavor(){
        System.out.println("Masala Popcorn");
    }
}
class ButterPopcorn extends Popcorn{
    public void flavor(){
        System.out.println("Butter Popcorn");
    }
}
class Main{
    public static void main(String[] args) {
        CheesePopcorn cp = new CheesePopcorn();
        MasalaPopcorn mp = new MasalaPopcorn();
        ButterPopcorn bp = new ButterPopcorn();
        cp.flavor();
        mp.flavor();
        bp.flavor();
        new Popcorn(){
            public void flavor(){
                System.out.println("Sweet Popcorn");
            }
        }.flavor();
    }
}