class Activa { 
	public void toStart() { 
		System.out.println("Cell Start"); 
	} 
} 
class Bike extends Activa { 
	public void start() { 
		System.out.println("Cell and Kick Start"); 
	} 
} 
class Bicycle extends Bike{
    public void starts(){
        System.out.println("No Cell and No Kick to start");
    }
}
class Main { 
	public static void main(String[] args) { 
		Bicycle bicycle = new Bicycle();
        bicycle.start(); 
        bicycle.toStart();
        bicycle.starts();
	} 
} 
