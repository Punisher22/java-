class Outer {
    public Outer(){
        System.out.println("Outer class created");
    }
    static class NestedDemo {
        public NestedDemo(){
            System.out.println("Static inner class created");
        }
        public void myMethod() {
           System.out.println("This is my nested class");
        }
    }
 }
 class Main{
    public static void main(String args[]) {
        Outer.NestedDemo nested = new Outer.NestedDemo();	 
        nested.myMethod();
     }
 }