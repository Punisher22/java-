class Main{
    public static void main(String[] args) {
        UgStudent ug = new UgStudent();
        ug.setName("Kevin");
        ug.setId(1);
        ug.setDept("IT");
        ug.setMarks(new int[] {80,90,85,95,70});
        GradeCalc ugc = new GradeCalc(ug);
        ugc.calcTotal();
        ugc.calcGrade();
    }
}