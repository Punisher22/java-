//14_1 Server side
import java.net.*;
import java.io.*;
class Server{       
    public static void main(String []args){
        try{
            ServerSocket serversocket=new ServerSocket(3000);
			Socket socket = serversocket.accept();
			DataInputStream dis=new DataInputStream(socket.getInputStream());
			String s;
    		s=dis.readUTF();
			System.out.println("Client say:"+s);
            socket.close();
        }catch(IOException e){
            System.out.println(e);
        }
    }
}

