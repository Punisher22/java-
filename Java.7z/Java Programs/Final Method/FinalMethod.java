class Parent{
    public final void display(){
       System.out.println("Hello welcome to Tutorialspoint");
    }
}    
class Child extends Parent{
       public void display(){
          System.out.println("hi");
       }
}
class Main{
    public static void main(String args[]){
        Child child = new Child();
        child.display();
     }
 
}