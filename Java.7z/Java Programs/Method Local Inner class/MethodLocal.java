class Outer { 
	void outerMethod() { 
		System.out.println("inside outerMethod"); 
		class Inner { 
			void innerMethod() { 
				System.out.println("inside innerMethod"); 
			} 
		} 
		Inner inner = new Inner(); 
		inner.innerMethod(); 
	} 
} 
class Main { 
	public static void main(String[] args) { 
		Outer outer = new Outer(); 
		outer.outerMethod(); 
	} 
} 
