class Main {
	public static void main(String[] args) {
		Employee e1 = new Employee();
		e1.setId(26);
		e1.setFname("Kevin");
		e1.setLname("Pandya");
		e1.setPresent(new int[] {1,1,1,0,1,1,1,0,1});
		e1.setTa(10);
		e1.setHra(20);
		EmployeeMgt mgt = new EmployeeMgt(e1);
		float salary;
		 mgt.getSalary();
		//System.out.println(salary);
	}
}
