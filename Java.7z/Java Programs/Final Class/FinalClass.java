final class Parent{
    public void show(){
        System.out.println("Parent's method");
    }
}
class Child extends Parent{
    void show(){
        System.out.println("Child's Method");
    }
}
class Main{
    public static void main(String[] args) {
        Child child = new Child();
        child.show();
    }
}