interface Outer { 
    interface Inner { 
        void show();	 
    } 
} 
class OuterImp implements Outer.Inner { 
    public void show() { 
        System.out.println("show method of interface"); 
    } 
} 
class Main { 
    public static void main(String[] args) { 
        Outer.Inner obj; 
        OuterImp t = new OuterImp(); 
        obj = t; 
        obj.show(); 
    } 
} 
