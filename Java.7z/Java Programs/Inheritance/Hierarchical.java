class Activa { 
	public void startActiva() { 
		System.out.println("To Start Activa"); 
	} 
} 
class Bike extends Activa { 
	public void startBike() { 
		System.out.println("To Start Bike"); 
	} 
} 
class Bicycle extends Activa{
    public void startBicycle(){
        System.out.println("To Start Bicycle");
    }
}
class Car extends Activa{
    public void startCar(){
        System.out.println("To Start Car");
    }
}
class Main { 
	public static void main(String[] args) { 
		Bicycle bicycle = new Bicycle();
        bicycle.startBicycle(); 
        Bike bike = new Bike();
        bike.startBike();
        Car car = new Car();
        car.startCar();
        car.startActiva();
	} 
} 
