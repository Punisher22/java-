class Hello{
    public static int enrollment_no = 26;
    public static void main(String args) {
        System.out.println("Greetings from " + enrollment_no + " enrollment number. This is my first program.");
    }
}