class Array{
    public static void main(String[] args) {
        int[] a;
        a = new int['a'];
        a[0] = 1;
        System.out.println(a[0]);
    }
}