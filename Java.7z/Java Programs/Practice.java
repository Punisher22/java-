class Greeting{
    public void sayHello(){
        System.out.println("Hello");
    }
    class Hello{
        public void sayHello(){
            Greeting g = new Greeting();
            System.out.println("Hey");
        }
    }
}
class Main{
    public static void main(String[] args) {
        Hello hello = new Hello();
        hello.g.sayHello();
    }
}