vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv// 14_2 server side
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;

class Server
{
    public static void main(final String[] array) throws IOException {
        final DatagramSocket datagramSocket = new DatagramSocket(1234);
        final byte[] buf = new byte[65535];
        datagramSocket.receive(new DatagramPacket(buf, buf.length));
        System.out.println(invokedynamic(makeConcatWithConstants:(Ljava/lang/StringBuilder;)Ljava/lang/String;, data(buf)));
        final byte[] array2 = new byte[65535];
    }
    
    public static StringBuilder data(final byte[] array) {
        if (array == null) {
            return null;
        }
        final StringBuilder sb = new StringBuilder();
        for (int n = 0; array[n] != 0; ++n) {
            sb.append((char)array[n]);
        }
        return sb;
    }
}