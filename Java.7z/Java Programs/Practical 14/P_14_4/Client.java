// 14_4 CLient side
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.InetAddress;
import java.net.Socket;
 
public class Client
{
 
    private static Socket socket;
 
    public static void main(String args[])
    {
        try
        {
            String host = "localhost";
            int port = 25000;
            InetAddress address = InetAddress.getByName(host);
            socket = new Socket(address, port);
 
            //Send the message to the server
            OutputStream os = socket.getOutputStream();
            OutputStreamWriter osw = new OutputStreamWriter(os);
            BufferedWriter bw = new BufferedWriter(osw);
			int[] num = new int[10];
			for(int i=0;i<10;i++){
				num[i]=10-i;
			}
			String s;
            for(int i=0;i<10;i++){
				s=String.valueOf(num[i]+"\n");
				bw.write(s);
				bw.flush();
				System.out.println("Message sent to the server : "+num[i]);
			}
 
            //Get the return message from the server
            InputStream is = socket.getInputStream();
            InputStreamReader isr = new InputStreamReader(is);
            BufferedReader br = new BufferedReader(isr);
            for(int i=0;i<10;i++){
				num[i] =  Integer.parseInt(br.readLine());
				System.out.println("Message received from client is "+num[i]);
			}
		}
        catch (Exception exception)
        {
            exception.printStackTrace();
        }
        finally
        {
            //Closing the socket
            try
            {
                socket.close();
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
        }
    }
}