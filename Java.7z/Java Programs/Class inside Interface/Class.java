interface Outer {
    class Inner {
        void m1(){
            System.out.println("inside m1");
        }
    }
}
class Main extends Outer.Inner{
    public static void main(String args[]){
        Outer.Inner ia = new Outer.Inner();
        ia.m1();
    }
}