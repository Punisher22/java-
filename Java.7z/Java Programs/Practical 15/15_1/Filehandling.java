import java.io.*;
class Filehandling{
    public static void main(String[] args) {
        try{
            FileOutputStream fos=new FileOutputStream("f1.txt");
            int b=1;
            fos.write(b);
            fos.close();
            
            FileInputStream fis=new FileInputStream("f1.txt");
            b=fis.read();
            System.out.println(b);
            fis.close();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}