class Activa { 
	public void toStart() { 
		System.out.println("Cell Start"); 
	} 
} 

class Bike extends Activa { 
	public void start() { 
		System.out.println("Cell and Kick Start"); 
	} 
} 
class Main { 
	public static void main(String[] args) { 
		Bike bike = new Bike(); 
        Activa activa = new Activa();
        bike.start(); 
		bike.toStart();
	} 
} 
