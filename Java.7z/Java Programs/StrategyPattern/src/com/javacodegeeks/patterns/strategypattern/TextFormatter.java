public interface TextFormatter {
	public void format(String text);
}