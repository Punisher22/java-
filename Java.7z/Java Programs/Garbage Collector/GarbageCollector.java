class GarbageCollector{
    public static void main(String[] args) {
        Runtime runtime = Runtime.getRuntime();
        System.out.println("Occupied Memory =" + (runtime.totalMemory()));
        int[] a = new int[1000];
        int[] b = new int[20];
        System.out.println("After creating multiple int type object :");
        System.out.println((runtime.totalMemory() - runtime.freeMemory()));
    }
}