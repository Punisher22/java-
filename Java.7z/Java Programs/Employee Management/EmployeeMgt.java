public class EmployeeMgt{
	Employee emp = null;
	
	public EmployeeMgt(Employee e1){
		this.emp = e1;
	}
	
	public void getSalary(){
		int count = 0;
		int [] present = emp.getPresent();
		for(int i=0; i<present.length; i++){
			if(present[i] ==1 ){
				count++;
			}
		}
		emp.setSalary(count * (500 + emp.getTa()/100 + emp.getHra()/100));
		System.out.println(emp.getSalary());
	}
}