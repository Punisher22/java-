package package_two; 
  
public class ClassTwo { 
    public void methodClassTwo(){ 
        System.out.println("Hello there i am ClassTwo"); 
    }     
}