class Outer {
    public Outer() {
        System.out.println("Outer class created");
    }
    public void m1(){
        System.out.println("Outer class method");
    }
    class Inner {
        public Inner() {
            System.out.println("Inner class created");
        }
        public void m1(){
            System.out.println("Inner class method");
            m1();
        } 
    }
}
class Main {
    public static void main(String[] args) {
        Outer outer = new Outer();
        Outer.Inner inner = outer.new Inner();
        inner.m1();
    }
}