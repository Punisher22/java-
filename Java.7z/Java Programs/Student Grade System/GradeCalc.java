public class GradeCalc{
    int total = 0;
    UgStudent ug = new UgStudent();
    PgStudent pg = new PgStudent();
    Student s1 = null;
    public GradeCalc(Student s){
        if(s.getClass().getName().equals("UgStudent")){
            ug = (UgStudent)s;
            for(int i : ug.getMarks()){
                total = total + i;
            }
        } else {
            pg = (PgStudent)s;
            for(int i : pg.getMarks()){
                total = total + i;
            }
        }
    }
    public void calcGrade(){
        if(total >= 450 && total <= 500)
            System.out.println("Grade = A");
        else if(total >= 400 && total <= 450)
            System.out.println("Grade = B");
    }
    public void calcTotal(){
        System.out.println("Total = " + total);
    }
}