public class UgStudent extends Student{
    int marks[] = null;
    String dept;
    public void setMarks(int[] marks){
        this.marks = marks;
    }
    public int[] getMarks(){
        return marks;
    }
    public void setDept(String dept){
        this.dept = dept;
    }
    public String getDept(){
        return dept;
    }
}