public class Employee{
	public String fname;
	public String lname;
	public int id;
    public int ta;
    public int hra;
    public float salary;
    public int[] present;

	public String getFname(){
		return fname;
	}
	public void setFname(String fname){
		this.fname = fname;
	}
	public String getLname(){
		return lname;
	}
	public void setLname(String lname){
		this.lname = lname;
	}
	public int getId(){
		return id;
	}
	public void setId(int id){
		this.id=id;
	}
	public int[] getPresent(){
		return present;
	}
	public void setPresent(int[] present){
		this.present = present;
	}
	public int getHra(){
		return hra;
	}
	public void setHra(int hra){
		this.hra = hra;
	}
	public int getTa(){
		return hra;
	}
	public void setTa(int ta){
		this.ta = ta;
	}
	public float getSalary(){
		return salary;
	}
	public void setSalary(float salary){
		this.salary = salary;
	}
}

